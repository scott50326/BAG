package tw.finalproject.contactus.model;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ContactUsRepository extends JpaRepository<ContactUsBean, Integer> {

}
