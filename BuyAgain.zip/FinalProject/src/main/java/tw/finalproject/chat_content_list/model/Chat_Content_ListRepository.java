package tw.finalproject.chat_content_list.model;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Chat_Content_ListRepository extends JpaRepository<Chat_Content_ListBean, Integer> {
}
