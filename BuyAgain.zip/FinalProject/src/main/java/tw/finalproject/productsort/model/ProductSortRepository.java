package tw.finalproject.productsort.model;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductSortRepository extends JpaRepository<ProductSortBean, Integer> {

}
